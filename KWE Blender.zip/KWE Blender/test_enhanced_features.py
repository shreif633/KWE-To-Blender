#
# Test Script for Enhanced KCM Features
# Run this in Blender's scripting workspace to test the new functionality
#
import bpy
import os
import sys

# Add the current directory to Python path so we can import our modules
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# Import our enhanced modules
try:
    from kcm_file import debug_texture_loading, list_available_textures, EnvFileData
    from gtx_converter import convert_gtx_to_dds
    print("✓ Successfully imported enhanced KCM modules")
except ImportError as e:
    print(f"✗ Failed to import modules: {e}")
    print("Make sure you're running this script from the KWE To Blender directory")
    sys.exit(1)

def test_env_file_loading():
    """Test ENV file loading functionality"""
    print("\n=== Testing ENV File Loading ===")
    
    # You need to set this to your actual Kal Online installation path
    game_path = r"C:\KalOnline"  # Change this!
    
    if not os.path.exists(game_path):
        print(f"✗ Game path not found: {game_path}")
        print("Please edit the game_path variable in this script")
        return False
    
    env_path = os.path.join(game_path, "Data", "3dData", "Env", "g_env.env")
    if not os.path.exists(env_path):
        print(f"✗ ENV file not found: {env_path}")
        return False
    
    # Test ENV file loading
    env_data = EnvFileData()
    env_data.load(env_path)
    
    print(f"✓ ENV file loaded successfully")
    print(f"  Grass types: {len(env_data.grass_list)}")
    print(f"  Textures: {len(env_data.texture_index_list)}")
    
    if len(env_data.texture_index_list) > 0:
        print(f"  First few textures: {env_data.texture_index_list[:5]}")
    
    return True

def test_texture_conversion():
    """Test GTX to DDS conversion"""
    print("\n=== Testing Texture Conversion ===")
    
    game_path = r"C:\KalOnline"  # Change this!
    
    if not os.path.exists(game_path):
        print(f"✗ Game path not found: {game_path}")
        return False
    
    # Check for encryption files
    encrypt_path = os.path.join(game_path, "Data", "EnCrypt.dat")
    decrypt_path = os.path.join(game_path, "Data", "DeCrypt.dat")
    
    if not os.path.exists(encrypt_path):
        print(f"✗ EnCrypt.dat not found: {encrypt_path}")
        return False
    
    if not os.path.exists(decrypt_path):
        print(f"✗ DeCrypt.dat not found: {decrypt_path}")
        return False
    
    print("✓ Encryption files found")
    
    # Test conversion with first few textures
    debug_texture_loading(game_path, [0, 1, 2])
    
    return True

def test_material_creation():
    """Test material creation with textures"""
    print("\n=== Testing Material Creation ===")
    
    # Create a simple test mesh
    bpy.ops.mesh.primitive_plane_add(size=10, location=(0, 0, 0))
    test_obj = bpy.context.active_object
    test_obj.name = "Test_Terrain"
    
    # Add some fake KCM data
    test_obj['kcm_header'] = {
        'map_x': 0,
        'map_y': 0,
        'texture_list': [0, 1, 2, 255, 255, 255, 255]  # Use first 3 textures
    }
    
    test_obj['kcm_textures'] = {
        'texture_list': [0, 1, 2, 255, 255, 255, 255],
        'env_textures': ['test_tex_0.gtx', 'test_tex_1.gtx', 'test_tex_2.gtx'],
        'game_path': r"C:\KalOnline"  # Change this!
    }
    
    # Create a simple material to test the system
    mat = bpy.data.materials.new(name="Test_Material")
    mat.use_nodes = True
    test_obj.data.materials.append(mat)
    
    print("✓ Test material created")
    print(f"  Object: {test_obj.name}")
    print(f"  Material: {mat.name}")
    print(f"  Texture list: {test_obj['kcm_header']['texture_list']}")
    
    return True

def test_viewport_setup():
    """Test viewport configuration"""
    print("\n=== Testing Viewport Setup ===")
    
    try:
        from kcm_file import setup_viewport_for_textures
        setup_viewport_for_textures()
        print("✓ Viewport configured for texture display")
    except Exception as e:
        print(f"✗ Viewport setup failed: {e}")
        return False
    
    return True

def run_all_tests():
    """Run all tests"""
    print("=== Enhanced KCM Features Test Suite ===")
    print("This script tests the enhanced texture loading and display features")
    print("\nIMPORTANT: Edit the game_path variables in this script to point to your Kal Online installation")
    
    tests = [
        ("ENV File Loading", test_env_file_loading),
        ("Texture Conversion", test_texture_conversion),
        ("Material Creation", test_material_creation),
        ("Viewport Setup", test_viewport_setup)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"✗ {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    print("\n=== Test Results ===")
    passed = 0
    for test_name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\nPassed: {passed}/{len(results)} tests")
    
    if passed == len(results):
        print("🎉 All tests passed! The enhanced KCM system is working correctly.")
    else:
        print("⚠️  Some tests failed. Check the error messages above.")
        print("Most likely causes:")
        print("- Incorrect game path (edit the game_path variables)")
        print("- Missing Kal Online installation files")
        print("- Missing encryption tables (EnCrypt.dat, DeCrypt.dat)")

if __name__ == "__main__":
    run_all_tests()
