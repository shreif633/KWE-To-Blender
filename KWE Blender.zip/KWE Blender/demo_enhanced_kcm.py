#
# Enhanced KCM Terrain Demo Script
# This script demonstrates the new texture features
#
import bpy
import os
from kcm_file import import_kcm, get_texture_info, setup_viewport_for_textures

def demo_enhanced_kcm_import():
    """
    Demonstration of the enhanced KCM importer with real texture display
    """
    print("=== Enhanced KCM Terrain Importer Demo ===")

    # Example paths - adjust these to your actual game installation
    game_path = r"C:\KalOnline"  # Change this to your Kal Online installation path
    kcm_file_path = r"C:\KalOnline\Data\3dData\Map\0_0.kcm"  # Example KCM file

    # Check if paths exist
    if not os.path.exists(game_path):
        print(f"Game path not found: {game_path}")
        print("Please edit the game_path variable in this script to point to your Kal Online installation")
        return

    if not os.path.exists(kcm_file_path):
        print(f"KCM file not found: {kcm_file_path}")
        print("Please edit the kcm_file_path variable to point to a valid KCM file")
        return

    # Clear existing mesh objects
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)

    print(f"Importing KCM file: {kcm_file_path}")
    print(f"Using game path: {game_path}")

    # Import the KCM terrain with enhanced features (now at 5% size)
    import_kcm(
        filepath=kcm_file_path,
        game_path=game_path,
        terrain_grid_scale=10.0,  # Will be automatically reduced to 5% (0.5)
        height_scale=0.1          # Will be automatically reduced to 5% (0.005)
    )

    # Get the imported terrain object
    terrain_obj = bpy.context.active_object
    if not terrain_obj:
        print("Failed to import terrain")
        return

    print(f"Successfully imported terrain: {terrain_obj.name} (at 5% original size)")

    # Display texture information
    texture_info = get_texture_info(terrain_obj)
    if texture_info:
        print(f"\nTexture Information for {texture_info['terrain_name']}:")
        print(f"Total textures: {texture_info['texture_count']}")

        for tex in texture_info['textures']:
            status = "✓ Loaded" if tex['has_image'] else "✗ Missing"
            print(f"  Texture {tex['index']}: {tex['name']} - {status}")
            if tex['has_image']:
                print(f"    Image: {tex['image_name']} ({tex['image_size'][0]}x{tex['image_size'][1]})")

    # Configure viewport for best texture display
    setup_viewport_for_textures()

    print("\n=== Demo Complete ===")
    print("New Features Available:")
    print("1. Terrain is now 5% of original size for better viewport performance")
    print("2. Use 'ENV Texture Browser' panel to see all available textures")
    print("3. Convert all GTX files to DDS with one click")
    print("4. Replace terrain textures from the ENV texture list")
    print("5. Real-time texture preview in Material Preview mode")
    print("6. Enhanced texture management with status indicators")


def demo_env_texture_browser():
    """
    Demonstration of the ENV texture browser functionality
    """
    print("\n=== ENV Texture Browser Demo ===")

    game_path = r"C:\KalOnline"  # Change this to your Kal Online installation path

    if not os.path.exists(game_path):
        print(f"Game path not found: {game_path}")
        return

    # Load and display ENV texture list
    from kcm_file import get_env_texture_list, convert_all_gtx_to_dds

    print("Loading ENV texture list...")
    env_textures = get_env_texture_list(game_path)

    if not env_textures:
        print("No textures found in ENV file")
        return

    print(f"Found {len(env_textures)} textures in ENV file")

    # Show status summary
    ready_count = len([t for t in env_textures if t['ready_for_use']])
    convertible_count = len([t for t in env_textures if t['can_convert']])
    missing_count = len(env_textures) - convertible_count

    print(f"Status Summary:")
    print(f"  Ready for use (DDS exists): {ready_count}")
    print(f"  Can be converted (GTX exists): {convertible_count}")
    print(f"  Missing GTX files: {missing_count}")

    # Show first 10 textures as example
    print(f"\nFirst 10 textures:")
    for i, texture in enumerate(env_textures[:10]):
        status = "READY" if texture['ready_for_use'] else "CONVERTIBLE" if texture['can_convert'] else "MISSING"
        print(f"  {i:3d}: {texture['name']} - {status}")

    # Offer to convert all textures
    print(f"\nTo convert all GTX files to DDS, use:")
    print(f"  1. The 'Convert All GTX to DDS' button in the ENV Texture Browser panel")
    print(f"  2. Or call: convert_all_gtx_to_dds('{game_path}')")


def demo_texture_replacement_from_env():
    """
    Demonstration of replacing terrain textures from ENV list
    """
    print("\n=== ENV Texture Replacement Demo ===")

    # Get the active object (should be a KCM terrain)
    obj = bpy.context.active_object
    if not obj or 'kcm_textures' not in obj:
        print("Please import a KCM terrain first using demo_enhanced_kcm_import()")
        return

    print(f"Working with terrain: {obj.name}")

    # Show current texture setup
    texture_data = obj.get('kcm_textures', {})
    texture_list = texture_data.get('texture_list', [])
    env_textures = texture_data.get('env_textures', [])

    print("Current terrain texture setup:")
    for i, tex_idx in enumerate(texture_list):
        if tex_idx == 255:
            continue
        tex_name = env_textures[tex_idx] if tex_idx < len(env_textures) else "Unknown"
        print(f"  Slot {i}: ENV Index {tex_idx} - {tex_name}")

    print("\nTo replace textures:")
    print("1. Use the 'ENV Texture Browser' panel")
    print("2. Find the texture you want to use")
    print("3. Click 'Use' next to the texture")
    print("4. Or use the 'Replace' button in the 'KCM Texture Manager' panel")
    print("5. Textures will be automatically converted from GTX to DDS if needed")

def demo_texture_replacement():
    """
    Demonstration of texture replacement functionality
    """
    print("\n=== Texture Replacement Demo ===")
    
    # Get the active object (should be a KCM terrain)
    obj = bpy.context.active_object
    if not obj or 'kcm_textures' not in obj:
        print("Please select a KCM terrain object first")
        return
    
    print(f"Working with terrain: {obj.name}")
    
    # Show current texture information
    texture_info = get_texture_info(obj)
    if texture_info:
        print("Current textures:")
        for tex in texture_info['textures']:
            print(f"  {tex['index']}: {tex['name']} ({'Loaded' if tex['has_image'] else 'Missing'})")
    
    print("\nTo replace textures:")
    print("1. Use the 'KCM Texture Manager' panel in the 3D viewport sidebar")
    print("2. Click the folder icon next to any texture to replace it")
    print("3. Select a new image file (DDS, PNG, JPG, TGA supported)")
    print("4. The texture will be updated in real-time in the viewport")

if __name__ == "__main__":
    # Run the main demo
    demo_enhanced_kcm_import()

    # Run additional demos
    demo_env_texture_browser()
    demo_texture_replacement_from_env()

    print("\n" + "="*60)
    print("ENHANCED KCM SYSTEM FEATURES SUMMARY:")
    print("="*60)
    print("✅ Terrain size reduced to 5% for better performance")
    print("✅ Real texture display in viewport (Material Preview mode)")
    print("✅ ENV texture browser with full texture list")
    print("✅ One-click GTX to DDS conversion for all textures")
    print("✅ Easy texture replacement from ENV list")
    print("✅ Texture status indicators (Ready/Convertible/Missing)")
    print("✅ Enhanced UI panels for texture management")
    print("✅ Automatic viewport configuration for best display")
    print("="*60)
    print("Check the 'Kal Tools' panel in the 3D viewport sidebar!")
