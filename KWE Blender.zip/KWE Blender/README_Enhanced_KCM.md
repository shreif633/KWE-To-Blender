# Enhanced KCM Terrain Importer for Blender

This enhanced version of the KCM (Kal Online Client Map) importer provides real texture display in Blender's viewport and powerful texture management tools with complete ENV file integration.

## 🆕 Latest Features (v2.0)

### 🎨 Real Texture Display
- **Viewport Textures**: Textures now display correctly in Material Preview and Rendered viewport modes
- **Automatic Conversion**: GTX textures are automatically converted to DDS format for Blender compatibility
- **High Quality**: Proper texture interpolation and color space settings for best visual quality
- **Multi-texture Blending**: Supports the original KCM multi-texture blending system using vertex colors
- **5% Terrain Size**: Terrain is automatically scaled to 5% of original size for better viewport performance

### 🗂️ ENV Texture Browser
- **Complete Texture List**: Browse all textures available in the n.env file
- **Status Indicators**: See which textures are ready, convertible, or missing
- **One-Click Conversion**: Convert all GTX files to DDS format with a single button
- **Texture Statistics**: View conversion status and availability summary
- **Direct Replacement**: Replace terrain textures directly from the ENV list

### 🛠️ Enhanced Texture Management
- **Terrain Texture Manager**: View and manage textures used in the current terrain
- **ENV-Based Replacement**: Replace textures using the complete ENV texture database
- **Real-time Preview**: See texture changes immediately in the viewport
- **Export Textures**: Export individual textures for editing in external programs
- **Texture Information**: See texture names, sizes, and loading status

### 📁 Advanced ENV File Support
- **Robust Parsing**: Improved ENV file reader with comprehensive error handling
- **Complete Texture Mapping**: Access to all textures referenced in the ENV file
- **Conversion Management**: Track GTX to DDS conversion status for all textures
- **Performance Optimized**: Efficient loading and caching of texture data

## Installation

1. Copy the `kal addons` folder to your Blender addons directory
2. Enable the addon in Blender Preferences > Add-ons
3. Set your Kal Online game path in the addon preferences

## Usage

### Basic Import
1. Go to File > Import > Kal Online Map (.kcm)
2. Select your KCM file
3. Set the game path to your Kal Online installation
4. Adjust terrain and height scales as needed (will be automatically reduced to 5%)
5. Click Import

### ENV Texture Browser
1. Open the "ENV Texture Browser" panel in the 3D viewport sidebar
2. Click "Convert All GTX to DDS" to prepare all textures for use
3. Browse the complete list of available textures from the n.env file
4. Use status indicators to see which textures are ready (✓), convertible (↗), or missing (✗)
5. Click "Use" next to any texture to apply it to the active terrain

### Texture Management
1. After importing a terrain, use the "KCM Texture Manager" panel
2. View all textures currently used in the selected terrain
3. Replace textures using the ENV browser or external files
4. Export textures for editing in external programs
5. Refresh textures to reload after external changes

### Texture Replacement Workflow
1. **From ENV List**: Use the ENV Texture Browser to replace with any available texture
2. **From External File**: Use the file browser to load custom textures
3. **Real-time Preview**: Changes appear immediately in Material Preview mode
4. **Automatic Conversion**: GTX files are converted to DDS automatically as needed

### Viewport Display
- **Material Preview Mode**: Best for seeing textures with proper lighting (recommended)
- **Rendered Mode**: Highest quality display with full material effects
- **Solid Mode**: Shows only vertex colors (useful for blend map editing)
- **Automatic Setup**: Viewport is automatically configured for optimal texture display

## File Structure

```
kal addons/
├── __init__.py          # Main addon file with UI panels
├── kcm_file.py          # Enhanced KCM importer/exporter
├── gtx_converter.py     # GTX to DDS conversion
├── util.py              # Core utilities and encryption
├── opl_file.py          # Object placement list support
└── ksm_file.py          # Server map support
```

## Technical Details

### Texture System
- Textures are stored in `{temp}/kal_textures/` as DDS files
- Original GTX files are converted using the game's encryption tables
- Blender materials use node-based mixing for multi-texture blending
- Vertex colors control texture blending weights

### Material Setup
- **Base Textures**: Up to 7 textures can be blended per terrain
- **Blend Maps**: Vertex color layers control texture mixing
- **Color Map**: RGB vertex colors provide additional tinting
- **UV Mapping**: Automatic UV coordinates based on terrain grid

### Performance
- Textures are cached after first conversion
- Viewport shading is automatically optimized
- Materials use efficient node setups for real-time display

## Troubleshooting

### Textures Not Showing
1. Check that your game path is set correctly in addon preferences
2. Ensure EnCrypt.dat and DeCrypt.dat exist in the game's Data folder
3. Switch viewport shading to Material Preview or Rendered mode
4. Check the console for error messages

### Missing Textures
1. Verify the g_env.env file exists in Data/3dData/Env/
2. Check that referenced GTX files exist in Data/3dData/Texture/
3. Use the "Refresh Textures" button in the texture manager

### Performance Issues
1. Reduce terrain scale for large maps
2. Use lower resolution textures if needed
3. Switch to Solid viewport mode for editing

## Advanced Usage

### Custom Texture Replacement
```python
import bpy
from kcm_file import get_texture_info

# Get texture info for active terrain
obj = bpy.context.active_object
info = get_texture_info(obj)

# Replace texture programmatically
mat = obj.data.materials[0]
tex_node = mat.node_tree.nodes.get("Texture_0")
if tex_node:
    new_img = bpy.data.images.load("path/to/new/texture.png")
    tex_node.image = new_img
```

### Viewport Configuration
```python
from kcm_file import setup_viewport_for_textures
setup_viewport_for_textures()  # Optimize viewport for texture display
```

## Credits

- Original KCM format reverse engineering
- Enhanced by AI for improved Blender integration
- Based on Delphi 7 source code analysis
- Uses Kal Online's encryption system for GTX conversion

## License

This tool is for educational and modding purposes. Respect the original game's terms of service.
